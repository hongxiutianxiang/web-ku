/*
* @Author: TomChen
* @Date:   2019-04-11 20:10:19
* @Last Modified by:   TomChen
* @Last Modified time: 2019-04-12 20:11:26
*/
export const ADD_ITEM = 'todolist@add_item'
export const CHANGE_ITEM = 'todolist@change_item'
export const DEL_ITEM = 'todolist@del_item'
export const LOAD_DATA = 'todolist@load_data'