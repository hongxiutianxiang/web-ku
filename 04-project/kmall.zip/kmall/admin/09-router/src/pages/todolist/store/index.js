/*
* @Author: TomChen
* @Date:   2019-04-12 20:04:31
* @Last Modified by:   TomChen
* @Last Modified time: 2019-04-12 20:05:55
*/
import reducer from './reducer.js'
import * as actionCreator from './actionCreator.js'

export { reducer,actionCreator }